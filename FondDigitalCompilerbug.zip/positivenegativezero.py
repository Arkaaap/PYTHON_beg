def comaprison (n):
  if (n>0):
    print ("Postive dude !!")
  elif (n<0):
    print ("Negative dude !")

  else:
    print ("Zero dude !")



n = int(input("Enter the n:"))
comaprison(n)
