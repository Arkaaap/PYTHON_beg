




pi = 3.14159

radius = int(input("Enter the radius of the circle : "))



area = pi * radius * radius
circumference = 2 * pi * radius
print (area)
print (circumference)

