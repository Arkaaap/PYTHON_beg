def leapyear (n):
  if (n%4 == 0 or n%400 == 0 and n%100 == 0):
      print ("Leap year:\n")
  else :
      print ("Not a leapyear")



n = int(input("Enter the year:"))
print (leapyear(n))