def evenorodd(n):
  if (n % 2 == 0):print("Yes")
  else:print ("Not a chance ")



n = int(input("Enter a number : "))
print(evenorodd(n))