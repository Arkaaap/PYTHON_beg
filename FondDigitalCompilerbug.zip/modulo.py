a = int(input("Enter the value of a:"))
b = int(input("Enter the value of b:"))
x = a%b
print (x)
