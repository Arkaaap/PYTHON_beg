def swap(a,b):
  a = a+b
  b = a-b
  a = a-b



  return a,b



a = int(input("Enter the value of a : "))
b = int (input("Enter the value of b : "))
print("Before swapping : ")
print ("a = ",a)
print ("b = ",b)
a,b = swap(a,b)
print("After swapping : ")
print ("a = ",a)
print ("b = ",b)