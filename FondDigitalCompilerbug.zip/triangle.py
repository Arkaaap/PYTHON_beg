# #include<stdio.h>
# int main()
# { float b ,h, area;
# b= 5;
# h= 13;
# area = (b*h) / 2 ;
# printf("\n\n Area of Triangle is: %f",area);
# # return (0);



base = int (input("Enter the base :"))
height = int (input("Enter the height :"))
area = (base*height)/2
print ("The area of the triangle is : ",area)