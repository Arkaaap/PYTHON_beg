def sum(a,b):
  return a+b



a = int(input("Enter the a:"))
b = int(input("Enter the b:"))
sum (a,b)
  