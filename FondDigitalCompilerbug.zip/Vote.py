def vote(n):
  if (n >= 18):
    print("Yep buddy , You can vote ")
  else:
    print("Sorry buddy , You can't vote ")


n = int(input("Enter your age : "))
vote(n)
