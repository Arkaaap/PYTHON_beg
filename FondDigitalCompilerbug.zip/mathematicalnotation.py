def mathematicalexpression (b,c,x):
   a= 0
   a= b*x+c





b = int(input("Enter the value of b :"))
c = int(input("Enter the value of c : "))
x = int(input("Enter the value of x : "))
a = print (mathematicalexpression(b,c,x))