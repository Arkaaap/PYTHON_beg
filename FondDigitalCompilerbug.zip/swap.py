def swap (a,b):
 return b,a
 


a = int(input("Enter the value of a : "))
b = int(input("Enter the value of b : "))
print("Before swapping : ")
print("a = ",a)
print("b = ",b)
a,b = swap(a,b)
print ("a  = ",a)
print ("b = ",b)
print("After swapping : ")