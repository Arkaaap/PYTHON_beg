def Revrese_(n):
    s = str(n)
    return s[::-1]
if __name__ == '__main__':
    n = int(input("ENTER THE N :"))
    print (Revrese_(n))