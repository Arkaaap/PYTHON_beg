'''Python Program to find all the didvisors of an integer '''

def Find(n):
    c = 0 
    for i in range (1,n+1):
        if (n%i== 0):
            c = c+1
            print(i) 
            print ()
            print (f"The Count of divisors {n} of the is {c}")



if __name__ == '__main__':
    n = int(input("Enter the N :"))
    Find(n)